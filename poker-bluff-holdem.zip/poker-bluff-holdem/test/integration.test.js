'use strict';
process.env.FAST = '1';
process.env.GRACE_MS = '1500';
process.env.HOST_GRACE_MS = '250';
process.env.ACTION_MS = '1500';
const test = require('node:test');
const assert = require('node:assert/strict');
const WebSocket = require('ws');
const { server, rooms } = require('../server');

let URL_WS;
test.before(() => new Promise((r) => server.listen(0, () => { URL_WS = 'ws://127.0.0.1:' + server.address().port + '/ws'; r(); })));
test.after(() => { for (const c of WebSocket.Server ? [] : []) c; server.close(); setTimeout(() => process.exit(0), 50); });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cardKey = (c) => JSON.stringify({ v: c.v, s: c.s });
const SETTINGS = { startStack: 300, sb: 5, bb: 10, actionSecs: 30 };

class Client {
  constructor(name) { this.name = name; this.state = null; this.msgs = []; this.errors = []; this.events = []; this.sentTurn = null; this.auto = false; this.violations = []; }
  open() {
    return new Promise((res, rej) => {
      this.ws = new WebSocket(URL_WS);
      this.ws.on('open', res); this.ws.on('error', rej);
      this.ws.on('message', (raw) => this.onMsg(String(raw)));
    });
  }
  send(o) { this.ws.send(JSON.stringify(o)); }
  onMsg(raw) {
    const msg = JSON.parse(raw);
    this.msgs.push(raw);
    if (msg.t === 'welcome') { this.code = msg.code; this.token = msg.token; this.id = msg.id; }
    if (msg.t === 'error') this.errors.push(msg.msg);
    if (msg.t !== 'state') return;
    this.state = msg.state; this.events.push(...msg.events);
    this.audit(raw, msg.state);
    if (this.auto) this.play();
  }
  audit(raw, st) {
    const room = rooms.get(st.code);
    const h = room && room.match && room.match.hand;
    if (!h) return;
    const mySeat = st.you ? st.you.seat : -1;
    for (const s of h.inHand) {
      if (s === mySeat || h.shown[s]) continue;
      for (const c of h.hole[s]) if (raw.includes(cardKey(c))) this.violations.push('hole card of seat ' + s + ' sent to ' + this.name);
    }
    for (const c of h.burned) if (raw.includes(cardKey(c))) this.violations.push('burn card leaked');
    for (const c of h.deck.slice(-6)) if (raw.includes(cardKey(c)) && !h.board.some((b) => b.v === c.v && b.s === c.s)) this.violations.push('deck card leaked');
    if (st.match) {
      const sum = st.match.seats.reduce((a, s) => a + s.stack, 0) + (st.match.hand && st.match.hand.status !== 'done' ? st.match.hand.pot : 0);
      if (sum !== st.match.total) this.violations.push('money mismatch ' + sum + ' vs ' + st.match.total);
    }
  }
  play() {
    const m = this.state && this.state.match;
    if (!m || !m.legal || !m.hand) return;
    if (this.sentTurn === m.hand.no + ':' + m.hand.turnId) return;
    this.sentTurn = m.hand.no + ':' + m.hand.turnId;
    const L = m.legal, opts = [];
    if (L.canCheck) opts.push({ action: 'check' });
    if (L.canCall) opts.push({ action: 'call' });
    if (L.canBet || L.canRaise) opts.push({ action: L.canBet ? 'bet' : 'raise', amount: L.minTo + Math.floor(Math.random() * (L.maxTo - L.minTo + 1) / 2) });
    if (L.canAllIn && Math.random() < 0.25) opts.push({ action: 'allin' });
    if (Math.random() < 0.15) opts.push({ action: 'fold' });
    const o = opts[Math.floor(Math.random() * opts.length)];
    setTimeout(() => { if (this.ws.readyState === 1) this.send(Object.assign({ t: 'act', turnId: m.hand.turnId }, o)); }, 2);
  }
  close() { try { this.ws.close(); } catch (e) { /* ignore */ } }
}
async function until(fn, ms = 20000, step = 10) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { if (fn()) return true; await sleep(step); }
  return false;
}
async function makeRoom(n, settings = SETTINGS) {
  const host = new Client('host'); await host.open();
  host.send({ t: 'create', name: 'المضيف', settings });
  await until(() => host.code);
  const cs = [host];
  for (let i = 1; i < n; i++) { const c = new Client('p' + i); await c.open(); c.send({ t: 'join', code: host.code, name: 'لاعب ' + i }); cs.push(c); }
  await until(() => cs.every((c) => c.state && c.state.members.length === n));
  return cs;
}

test('settings are validated on the server', async () => {
  const c = new Client('x'); await c.open();
  c.send({ t: 'create', name: 'س', settings: { startStack: 1000, sb: 5, bb: 15, actionSecs: 30 } });
  await until(() => c.errors.length);
  assert.match(c.errors[0], /ضعف/);
  c.send({ t: 'create', name: 'س', settings: { startStack: 5, sb: 5, bb: 10, actionSecs: 30 } });
  await until(() => c.errors.length > 1);
  assert.match(c.errors[1], /لا يجوز أن يقل/);
  c.close();
});

for (const n of [2, 7]) {
  test(n + '-player match plays to a single winner with no card leaks', async () => {
    const cs = await makeRoom(n);
    cs.forEach((c) => { c.auto = true; });
    cs[1].send({ t: 'start' });
    await until(() => cs[1].errors.length);
    assert.match(cs[1].errors[0], /مدير الغرفة/, 'non-host cannot start');
    cs[0].send({ t: 'start' });
    const ok = await until(() => cs[0].state && cs[0].state.status === 'ended', 60000);
    assert.ok(ok, 'match ended');
    const st = cs[0].state;
    const alive = st.match.seats.filter((s) => s.stack > 0);
    assert.equal(alive.length, 1);
    assert.equal(alive[0].stack, n * 300);
    for (const c of cs) assert.deepEqual(c.violations, [], c.name);
    const ev = cs[0].events;
    assert.ok(ev.some((e) => e.k === 'street' && e.street === 'river'));
    // every client saw identical public bot text at the end
    assert.equal(new Set(cs.map((c) => c.state.bot.text)).size, 1);
    cs.forEach((c) => c.close());
  });
}

test('reconnect keeps seat, stack and hole cards; duplicate requests are ignored', async () => {
  const cs = await makeRoom(3, { startStack: 1000, sb: 5, bb: 10, actionSecs: 30 });
  cs[0].send({ t: 'start' });
  await until(() => cs.every((c) => c.state.match && c.state.match.hand));
  const room = rooms.get(cs[0].code);
  const h = room.match.hand;
  // duplicate request from the player to act
  const toAct = h.toAct;
  const c = cs.find((x) => x.state.you.seat === toAct);
  const tid = h.turnId;
  const evBefore = room.evSeq;
  c.send({ t: 'act', turnId: tid, action: 'call' });
  c.send({ t: 'act', turnId: tid, action: 'call' });
  await sleep(150);
  const acts = c.events.filter((e) => e.id > evBefore && e.k === 'act' && e.seat === toAct);
  assert.equal(acts.length, 1, 'only one action applied');
  // reconnect a player
  const r = cs[2];
  const seat = r.state.you.seat, stack = r.state.match.seats[seat].stack, hole = JSON.stringify(r.state.match.hole);
  r.close();
  await until(() => cs[0].state.members.find((m) => m.id === r.id).connected === false);
  const r2 = new Client('again'); await r2.open();
  r2.send({ t: 'join', code: r.code, token: r.token });
  await until(() => r2.state);
  assert.equal(r2.state.you.id, r.id);
  assert.equal(r2.state.you.seat, seat);
  assert.equal(r2.state.match.seats[seat].stack, stack);
  assert.equal(JSON.stringify(r2.state.match.hole), hole);
  assert.equal(r2.state.members.length, 3, 'no duplicate member');
  cs.forEach((x) => x.close()); r2.close();
});

test('host leaving transfers admin; timeouts auto check/fold; spectators get no cards', async () => {
  const cs = await makeRoom(3, { startStack: 1000, sb: 5, bb: 10, actionSecs: 30 });
  cs[0].send({ t: 'start' });
  await until(() => cs.every((c) => c.state.match && c.state.match.hand));
  const hostId = cs[0].id;
  cs[0].close();
  const moved = await until(() => cs[1].state.hostId && cs[1].state.hostId !== hostId, 3000);
  assert.ok(moved, 'host transferred');
  assert.equal(cs[1].state.status, 'playing', 'match continues');
  // nobody acts: the player to act times out (ACTION_MS=1500)
  const before = cs[1].events.length;
  const timedOut = await until(() => cs[1].events.slice(before).some((e) => e.k === 'act' && e.auto), 6000);
  assert.ok(timedOut, 'auto action after timeout');
  const auto = cs[1].events.slice(before).find((e) => e.k === 'act' && e.auto);
  assert.ok(['check', 'fold'].includes(auto.a));
  // spectator joins mid-match
  const sp = new Client('spec'); await sp.open();
  sp.send({ t: 'join', code: cs[1].code, name: 'متفرج' });
  await until(() => sp.state);
  assert.equal(sp.state.you.role, 'spectator');
  assert.equal(sp.state.match.hole, null);
  assert.deepEqual(sp.violations, []);
  cs.forEach((x) => x.close()); sp.close();
});
