'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const H = require('../engine/holdem');

const P = (s) => { const m = { T: 10, J: 11, Q: 12, K: 13, A: 14 }; const r = s.slice(0, -1); return { v: m[r] || Number(r), s: s.slice(-1) }; };
const cards = (str) => str.split(' ').map(P);
const best = (str) => H.bestHand(cards(str));
const cmp = (a, b) => H.cmpScore(best(a), best(b));

function mk(n, opts = {}) {
  const players = Array.from({ length: n }, (_, i) => ({ id: 'p' + i, name: 'P' + i }));
  const m = H.createMatch({ players, startStack: opts.start || 1000, sb: opts.sb || 5, bb: opts.bb || 10, actionSecs: 30, rnd: () => 0 });
  if (opts.stacks) { opts.stacks.forEach((v, i) => { m.seats[i].stack = v; }); m.total = opts.stacks.reduce((a, b) => a + b, 0); }
  return m;
}
function setCards(m, holes, board) {
  const h = m.hand;
  for (const [s, str] of Object.entries(holes)) h.hole[s] = cards(str);
  if (board) {
    const b = cards(board);
    const used = new Set([...Object.values(h.hole).flat(), ...b].map((c) => c.v + c.s));
    const burns = H.newDeck().filter((c) => !used.has(c.v + c.s)).slice(0, 3);
    h.deck = [b[4], burns[2], b[3], burns[1], b[2], b[1], b[0], burns[0]];
  }
}
function act(m, seat, a, amt) {
  assert.equal(m.hand.toAct, seat, 'expected seat ' + seat + ' to act, got ' + m.hand.toAct);
  const r = H.act(m, seat, a, amt);
  assert.ok(r.ok, r.error);
  return r;
}
function finishStreets(m) { // deal remaining streets and showdown when nobody can bet
  while (m.hand.status === 'between' || m.hand.status === 'runout') H.dealStreet(m);
  if (m.hand.status === 'showdown') H.showdown(m);
}

/* ---------- evaluator ---------- */
test('hand ranking order and special cases', () => {
  assert.equal(best('As Ks Qs Js Ts 2d 3c').name, 'رويال فلش');
  assert.ok(cmp('As Ks Qs Js Ts 2d 3c', '9h 8h 7h 6h 5h 2d 3c') > 0);
  assert.equal(best('9h 8h 7h 6h 5h 2d 3c').cat, 9);
  assert.equal(best('Ah 2d 3c 4s 5h 9d Kc').cat, 5);
  assert.deepEqual(best('Ah 2d 3c 4s 5h 9d Kc').tb, [5]);
  assert.equal(best('Qh Kd Ac 2s 3h 8d 9c').cat, 1, 'no wrap-around straight');
  assert.ok(cmp('2h 3d 4c 5s 6h Jd Kc', 'Ah 2d 3c 4s 5h Jd Kc') > 0, '6-high beats wheel');
  assert.ok(cmp('9s 9h 9d 9c 2h Kd 3c', 'Ks Kh Kd Qc Qh 2d 3c') > 0, 'quads > full house');
  assert.ok(cmp('Ks Kh Kd Qc Qh 2d 3c', '2s 7s 9s Js As 3d 4c') > 0, 'full house > flush');
  assert.ok(cmp('2s 7s 9s Js As 3d 4c', '5h 6d 7c 8s 9h 2d Kc') > 0, 'flush > straight');
  assert.ok(cmp('Ah Ad 7c 7s 2h 9d Kc', 'Ah Ad 7c 7s 2h 9d Qc') > 0, 'two pair kicker');
  assert.ok(cmp('Ah Ad Kc 7s 2h 9d 4c', 'As Ac Qc 7d 2s 9h 4d') > 0, 'pair kicker');
  assert.equal(cmp('As Kh 2c 3d 7s 9h Jc', 'Ac Kd 2h 3s 7d 9c Js'), 0, 'suits never break ties');
});
test('board plays and one-card hands', () => {
  // board is a broadway straight; both players play the board
  const board = 'Ts Jd Qh Kc Ad';
  assert.equal(cmp('2c 3h ' + board, '4c 5h ' + board), 0);
  // one hole card makes the flush
  const b = best('As 2d Ks 9s 4s 7s Jh');
  assert.equal(b.cat, 6);
  assert.ok(b.cards.some((c) => c.v === 14 && c.s === 's'));
  assert.ok(!b.cards.some((c) => c.v === 2), 'unused hole card not in best five');
});

/* ---------- positions ---------- */
test('heads-up: button posts SB and acts first preflop, BB acts first postflop', () => {
  const m = mk(2);
  H.startHand(m);
  const h = m.hand;
  assert.equal(h.btnPos, 0); assert.equal(h.sbSeat, 0); assert.equal(h.bbSeat, 1);
  assert.equal(h.toAct, 0);
  act(m, 0, 'call');
  assert.equal(h.toAct, 1, 'BB gets the option');
  const L = H.legal(m, 1);
  assert.ok(L.canCheck && L.canRaise);
  act(m, 1, 'check');
  H.dealStreet(m);
  assert.equal(h.board.length, 3); assert.equal(h.burned.length, 1);
  assert.equal(h.toAct, 1, 'BB first after flop');
  H.assertMoney(m);
});
test('3+ players: UTG first preflop, first left of button postflop; button moves', () => {
  const m = mk(4);
  H.startHand(m);
  let h = m.hand;
  assert.deepEqual([h.btnPos, h.sbSeat, h.bbSeat, h.toAct], [0, 1, 2, 3]);
  act(m, 3, 'call'); act(m, 0, 'call'); act(m, 1, 'call');
  assert.equal(h.toAct, 2, 'BB option'); act(m, 2, 'check');
  H.dealStreet(m);
  assert.equal(h.toAct, 1, 'SB first postflop');
  act(m, 1, 'fold'); act(m, 2, 'fold'); act(m, 3, 'fold');
  assert.equal(h.status, 'done');
  H.startHand(m); h = m.hand;
  assert.deepEqual([h.btnPos, h.sbSeat, h.bbSeat, h.toAct], [1, 2, 3, 0]);
});
test('dead button after elimination; BB never skipped or repeated', () => {
  const m = mk(4);
  H.startHand(m); // btn0 sb1 bb2
  m.hand.status = 'done';
  for (const s of m.hand.inHand) { m.seats[s].stack += m.hand.committed[s]; }
  m.seats[3].stack = 0; m.seats[3].busted = true; m.seats[0].stack += 1000; // seat 3 eliminated (move money to keep total)
  H.startHand(m);
  let h = m.hand;
  // BB advances to next live after 2 → 0; SB is last BB (seat 2); button on last SB position (1)
  assert.deepEqual([h.btnPos, h.sbSeat, h.bbSeat], [1, 2, 0]);
  assert.equal(h.toAct, 1, 'first after BB');
  m.hand.status = 'done'; for (const s of h.inHand) m.seats[s].stack += h.committed[s];
  H.startHand(m); h = m.hand;
  assert.deepEqual([h.btnPos, h.sbSeat, h.bbSeat], [2, 0, 1]);
});
test('dead small blind when last big blind busts', () => {
  const m = mk(4);
  H.startHand(m); // btn0 sb1 bb2
  m.hand.status = 'done'; for (const s of m.hand.inHand) m.seats[s].stack += m.hand.committed[s];
  m.seats[0].stack += m.seats[2].stack; m.seats[2].stack = 0; m.seats[2].busted = true;
  H.startHand(m);
  const h = m.hand;
  assert.equal(h.bbSeat, 3); assert.equal(h.sbSeat, null, 'dead small blind'); assert.equal(h.btnPos, 1);
  assert.equal(h.toAct, 0);
  H.assertMoney(m);
});
test('going heads-up: nobody posts BB twice in a row', () => {
  const m = mk(3);
  H.startHand(m); // btn0 sb1 bb2
  m.hand.status = 'done'; for (const s of m.hand.inHand) m.seats[s].stack += m.hand.committed[s];
  m.seats[1].stack += m.seats[0].stack; m.seats[0].stack = 0; m.seats[0].busted = true;
  H.startHand(m);
  const h = m.hand;
  assert.notEqual(h.bbSeat, 2); assert.equal(h.bbSeat, 1); assert.equal(h.sbSeat, 2); assert.equal(h.btnPos, 2);
  assert.equal(h.toAct, 2, 'heads-up button acts first preflop');
});

/* ---------- betting rules ---------- */
test('minimum bet and minimum raise follow last full raise', () => {
  const m = mk(3);
  H.startHand(m); // btn0(toAct) sb1 bb2
  let L = H.legal(m, 0);
  assert.equal(L.minTo, 20);
  act(m, 0, 'raise', 30); // raise of 20
  L = H.legal(m, 1);
  assert.equal(L.minTo, 50);
  assert.equal(H.act(m, 1, 'raise', 45).ok, false, 'below min raise rejected');
  act(m, 1, 'raise', 100); // raise of 70
  assert.equal(H.legal(m, 2).minTo, 170);
  act(m, 2, 'fold'); act(m, 0, 'call');
  H.dealStreet(m);
  assert.equal(H.legal(m, 1).minTo, 10, 'opening bet min = big blind');
  assert.equal(H.act(m, 1, 'bet', 5).ok, false);
  act(m, 1, 'bet', 40);
  assert.equal(H.legal(m, 0).minTo, 80);
});
test('short all-in does not reopen; accumulated short all-ins do', () => {
  // A acts, B short all-in, C calls: A may only call/fold
  let m = mk(4, { stacks: [1000, 1000, 160, 1000] });
  H.startHand(m); // btn0 sb1 bb2 utg3
  act(m, 3, 'call'); act(m, 0, 'call'); act(m, 1, 'call'); act(m, 2, 'check');
  H.dealStreet(m); // first: 1
  act(m, 1, 'bet', 100);
  act(m, 2, 'allin'); // 150 total: short raise of 50
  assert.equal(m.hand.currentBet, 150);
  act(m, 3, 'call'); act(m, 0, 'call');
  let L = H.legal(m, 1);
  assert.equal(L.toCall, 50); assert.equal(L.canRaise, false, 'not reopened');
  // accumulation: two short all-ins total a full raise
  m = mk(5, { stacks: [1000, 1000, 160, 210, 1000] });
  H.startHand(m); // btn0 sb1 bb2 seat3 seat4
  act(m, 3, 'call'); act(m, 4, 'call'); act(m, 0, 'call'); act(m, 1, 'call'); act(m, 2, 'check');
  H.dealStreet(m);
  act(m, 1, 'bet', 100);
  act(m, 2, 'allin'); // to 150
  act(m, 3, 'allin'); // to 200
  act(m, 4, 'call'); act(m, 0, 'call');
  L = H.legal(m, 1);
  assert.equal(L.toCall, 100); assert.equal(L.canRaise, true, 'reopened by accumulated raises');
});
test('betting does not end on equal amounts before everyone acted', () => {
  const m = mk(3);
  H.startHand(m);
  act(m, 0, 'call'); act(m, 1, 'call');
  assert.equal(m.hand.status, 'betting'); assert.equal(m.hand.toAct, 2);
});
test('uncalled bet is returned and fold-out wins without showdown', () => {
  const m = mk(3);
  H.startHand(m);
  act(m, 0, 'raise', 300);
  act(m, 1, 'fold');
  const r = act(m, 2, 'fold');
  assert.ok(r.events.some((e) => e.k === 'refund' && e.seat === 0 && e.amount === 290));
  assert.equal(m.hand.status, 'done');
  assert.equal(m.seats[0].stack, 1015);
  assert.deepEqual(m.hand.shown, {}, 'no cards shown');
  H.assertMoney(m);
});
test('side pots: main and side pot won by different players, folded chips stay', () => {
  const m = mk(4, { stacks: [100, 300, 500, 500] });
  H.startHand(m); // btn0 sb1 bb2 seat3 first
  act(m, 3, 'raise', 30);
  act(m, 0, 'allin'); // 100
  act(m, 1, 'allin'); // 300
  act(m, 2, 'allin'); // 500
  act(m, 3, 'fold'); // 30 dead money
  setCards(m, { 0: 'As Ah', 1: 'Ks Kh', 2: 'Qs Qh' }, '2c 7d 9h 3s 4d');
  assert.equal(m.hand.status, 'runout');
  finishStreets(m);
  const res = m.hand.results;
  const main = res.pots[0], side = res.pots[1];
  assert.equal(main.amount, 100 * 3 + 30); assert.deepEqual(main.winners, [{ seat: 0, amount: 330 }]);
  assert.equal(side.amount, 400); assert.deepEqual(side.winners, [{ seat: 1, amount: 400 }]);
  assert.equal(res.pots.length, 2, 'excess 200 refunded, not a pot');
  assert.equal(m.seats[2].stack, 200);
  assert.equal(m.seats[0].stack + m.seats[1].stack + m.seats[2].stack + m.seats[3].stack, 1400);
  assert.ok(m.seats[3].busted === false);
});
test('split pot with odd chip goes to first winner left of the button', () => {
  const m = mk(3, { stacks: [1000, 1000, 1000] });
  H.startHand(m); // btn0 sb1 bb2
  act(m, 0, 'fold');
  act(m, 1, 'call');
  act(m, 2, 'check');
  // add an odd chip of dead money by giving a folded third seat contribution
  m.hand.committed[0] = 1; m.seats[0].stack -= 1;
  setCards(m, { 1: '2c 3d', 2: '2h 3s', 0: '9c 9d' }, 'As Ks Qd Jc 8h');
  for (let i = 0; i < 3; i++) {
    H.dealStreet(m);
    act(m, m.hand.toAct, 'check'); act(m, m.hand.toAct, 'check');
  }
  H.showdown(m);
  const pot = m.hand.results.pots[0];
  assert.equal(pot.amount, 21);
  assert.deepEqual(pot.winners, [{ seat: 1, amount: 11 }, { seat: 2, amount: 10 }]);
  assert.equal(m.seats.reduce((a, s) => a + s.stack, 0), 3000);
});
test('showdown order: river aggressor shows first, beaten hand may muck', () => {
  const m = mk(3);
  H.startHand(m);
  act(m, 0, 'call'); act(m, 1, 'call'); act(m, 2, 'check');
  setCards(m, { 0: 'As Ad', 1: '7c 2d', 2: 'Kc Kd' }, '3h 8s 9d Jc 4h');
  for (let i = 0; i < 2; i++) { H.dealStreet(m); act(m, 1, 'check'); act(m, 2, 'check'); act(m, 0, 'check'); }
  H.dealStreet(m);
  act(m, 1, 'check'); act(m, 2, 'bet', 20); act(m, 0, 'call'); act(m, 1, 'call');
  H.showdown(m);
  assert.ok(m.hand.shown[2], 'aggressor shows');
  assert.ok(m.hand.shown[0], 'better hand shows');
  assert.ok(m.hand.mucked[1], 'worse hand mucks');
  assert.equal(m.hand.results.pots[0].winners[0].seat, 0);
});
test('heads-up all-in for less than big blind', () => {
  const m = mk(2, { stacks: [1000, 4] });
  H.startHand(m); // btn0=sb posts 5, bb1 posts 4 all-in
  assert.equal(m.hand.status, 'runout', 'nobody can bet; board runs out');
  finishStreets(m);
  assert.equal(m.hand.status, 'done');
  assert.equal(m.seats[0].stack + m.seats[1].stack, 1004);
});

/* ---------- fuzz ---------- */
test('fuzz: 2-7 players, random actions, money invariant and termination', () => {
  let hands = 0;
  for (let g = 0; g < 400; g++) {
    const n = 2 + (g % 6);
    const m = mk(n, { start: 200 + (g % 5) * 150, sb: 5, bb: 10 });
    let lastBB = null;
    while (!m.over && m.handNo < 300) {
      H.startHand(m); hands++;
      const h = m.hand;
      const liveCnt = h.inHand.length;
      if (liveCnt >= 3 && lastBB !== null) assert.notEqual(h.bbSeat, lastBB, 'BB repeated');
      lastBB = h.bbSeat;
      let guard = 0;
      while (h.status !== 'done' && guard++ < 500) {
        if (h.status === 'betting') {
          const s = h.toAct, L = H.legal(m, s), opts = [];
          if (L.canCheck) opts.push(['check']);
          if (L.canCall) opts.push(['call']);
          if (L.canBet || L.canRaise) { opts.push([L.canBet ? 'bet' : 'raise', L.minTo + Math.floor(Math.random() * (L.maxTo - L.minTo + 1) / 3)]); }
          if (L.canAllIn && Math.random() < 0.15) opts.push(['allin']);
          if (Math.random() < 0.2) opts.push(['fold']);
          const o = opts[Math.floor(Math.random() * opts.length)];
          const r = H.act(m, s, o[0], o[1]);
          assert.ok(r.ok, o[0] + ' ' + r.error);
        } else if (h.status === 'between' || h.status === 'runout') H.dealStreet(m);
        else if (h.status === 'showdown') H.showdown(m);
        H.assertMoney(m);
      }
      assert.equal(h.status, 'done', 'hand terminated');
      assert.ok(h.board.length <= 5);
      const all = [...h.board, ...h.burned, ...Object.values(h.hole).flat()].map((c) => c.v + c.s);
      assert.equal(new Set(all).size, all.length, 'no duplicate cards');
    }
    assert.ok(m.over || m.handNo >= 300);
  }
  assert.ok(hands > 1000);
});
