process.env.FAST='1'; process.env.ACTION_MS='4000';
const path=require('path').join(__dirname,'..')+'/';
const { server, rooms } = require(path+'server.js');
const { JSDOM } = require('jsdom');
const fs=require('fs');
const html=fs.readFileSync(path+'public/index.html','utf8');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
server.listen(0, async()=>{
  const port=server.address().port, base='http://127.0.0.1:'+port+'/';
  const errs=[];
  const mk=(url,label)=>{ const d=new JSDOM(html,{url,runScripts:'dangerously',pretendToBeVisual:true});
    d.window.addEventListener('error',e=>errs.push(label+': '+e.message)); d.window.console.error=(...a)=>errs.push(label+' console: '+a.join(' '));
    d.window.matchMedia=()=>({matches:true}); d.window.HTMLElement.prototype.scrollIntoView=()=>{}; return d; };
  const w=[]; const host=mk(base,'host'); w.push(host); await sleep(100);
  const D=host.window.document;
  D.getElementById('goCreate').click();
  D.getElementById('cName').value='خالد';
  D.getElementById('cStart').value='400'; D.getElementById('cStart').dispatchEvent(new host.window.Event('input'));
  console.log('auto blinds', D.getElementById('cSB').value, D.getElementById('cBB').value);
  D.getElementById('createForm').dispatchEvent(new host.window.Event('submit',{cancelable:true}));
  await sleep(300);
  const code=D.getElementById('lCode').textContent; console.log('code',code,'link',D.getElementById('lLink').value);
  for(let i=1;i<4;i++){ const c=mk(base+'?room='+code,'p'+i); w.push(c); await sleep(80); const d=c.window.document;
    console.log('p'+i,'screen join visible', !d.getElementById('joinScreen').classList.contains('is-hidden'), 'code prefilled', d.getElementById('jCode').value);
    d.getElementById('jName').value='<img src=x>لاعب'+i; d.getElementById('joinForm').dispatchEvent(new c.window.Event('submit',{cancelable:true})); await sleep(150); }
  await sleep(200);
  console.log('lobby members (host view):', D.querySelectorAll('#lMembers li').length, '| start btn:', D.getElementById('btnStartMatch').textContent);
  console.log('non-host start hidden:', w[1].window.document.getElementById('btnStartMatch').classList.contains('is-hidden'));
  D.getElementById('btnStartMatch').click();
  await sleep(300);
  let steps=0, acted=0, sawResult=false, sawSide=false, talk=0;
  const t0=Date.now();
  while(Date.now()-t0<60000){
    await sleep(25); steps++;
    let over=false;
    for(const [i,c] of w.entries()){ const d=c.window.document;
      if(!d.getElementById('resultPanel').classList.contains('is-hidden')){ sawResult=true; if(d.getElementById('resultPanel').textContent.includes('الجانبي')) sawSide=true; }
      if(d.getElementById('resultPanel').textContent.includes('بطل المباراة')) over=true;
      // privacy: opponents' tiles must not contain faces unless shown
      const st=rooms.get(code).match; const h=st&&st.hand;
      if(h){ for(const s of h.inHand){ const tile=d.getElementById('opp-'+s); if(tile && !h.shown[s] && tile.querySelector('.opp-cards .face')) errs.push('face in hidden opp tile'); } }
      if(d.getElementById('actionPanel').classList.contains('is-hidden')) continue;
      const pick=Math.random(); const g=id=>d.getElementById(id);
      if(talk<2 && pick<0.02){ d.querySelector('.bluff').click(); talk++; }
      if(pick<0.12 && !g('btnAllIn').classList.contains('is-hidden') && !g('btnAllIn').disabled){ g('btnAllIn').click(); acted++; }
      else if(pick<0.35 && !g('btnAggro').classList.contains('is-hidden') && !g('btnAggro').disabled){ const q=d.querySelectorAll('.qbtn')[Math.floor(Math.random()*4)]; q.click(); g('btnAggro').click(); acted++; }
      else if(pick<0.45){ g('btnFold').click(); g('btnFold').click(); acted++; }
      else if(!g('btnCheckCall').disabled){ g('btnCheckCall').click(); acted++; }
    }
    if(over) break;
  }
  const d0=D;
  console.log('acted',acted,'sawResult',sawResult,'sawSidePot',sawSide);
  console.log('host result text:', d0.getElementById('resultPanel').textContent.replace(/\s+/g,' ').slice(0,200));
  console.log('newMatch btn for host:', !!d0.getElementById('btnNewMatch'), 'for p1:', !!w[1].window.document.getElementById('btnNewMatch'));
  console.log('opp name escaped:', d0.querySelector('#opps .nm') && d0.querySelector('#opps .nm').innerHTML);
  console.log('bot:', d0.getElementById('botText').textContent);
  console.log('hud:', d0.querySelector('.hud').textContent.replace(/\s+/g,' '));
  if(d0.getElementById('btnNewMatch')){ d0.getElementById('btnNewMatch').click(); await sleep(300); console.log('back to lobby:', !d0.getElementById('lobby').classList.contains('is-hidden'), 'edit visible', !d0.getElementById('btnEditSettings').classList.contains('is-hidden')); }
  // reload a client (reconnect via saved token)
  const ls = w[2].window.localStorage; const keys=Object.keys(ls); console.log('stored session keys', keys);
  console.log('errors', errs.slice(0,10), errs.length);
  process.exit(0);
});
